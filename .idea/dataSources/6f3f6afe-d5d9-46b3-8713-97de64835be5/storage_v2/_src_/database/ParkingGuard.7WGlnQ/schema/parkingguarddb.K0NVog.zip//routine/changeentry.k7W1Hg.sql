create function changeentry(personid_par integer, firstname_par character varying, lastname_par character varying, phonenumber_par character varying, startdate_par date, enddate_par date, numberplate_par character varying)
  returns boolean
language plpgsql
as $$
DECLARE
BEGIN
    update person
    set firstname=firstname_par, lastname=lastname_par, phonenumber=phonenumber_par, startdate=startDate_par, enddate=endDate_par, numberplate=numberplate_par
    WHERE personid=personid_par;

    return true;
END;
$$;

