create function checknumberplate(plate_param character varying)
  returns boolean
language plpgsql
as $$
DECLARE
    count integer;
    BEGIN
        SELECT count(*) FROM person WHERE current_date between startdate and enddate Into count;
        if count > 0 then
            return true;
        else
            return false;
        end if;
    end;
$$;

