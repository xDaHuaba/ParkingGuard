create function addentry(firstname_par character varying, lastname_par character varying, phonenumber_par character varying, startdate_par date, enddate_par date, numberplate_par character varying)
  returns integer
language plpgsql
as $$
DECLARE
    personID integer;
BEGIN
    --Inserts Entry into DB
    INSERT into person(firstname, lastname, phonenumber, startdate, enddate, numberplate)
        values (firstname_par, lastname_par, phonenumber_par, startDate_par, endDate_par, numberplate_par);

    --Gets PersonID from just created Entry
    SELECT personid from person
    where firstname = firstname_par
    and lastname = lastname_par
    and phonenumber = phonenumber_par
    and startdate = startDate_par
    and enddate = endDate_par
    and numberplate = numberplate_par into personID;
    
    --Returns PersonID
    return personID;
END;
$$;

