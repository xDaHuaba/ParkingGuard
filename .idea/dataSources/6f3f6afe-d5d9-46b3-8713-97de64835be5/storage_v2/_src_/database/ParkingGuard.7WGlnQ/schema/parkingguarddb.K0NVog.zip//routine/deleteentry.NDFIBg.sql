create function deleteentry(personid_par integer)
  returns boolean
language plpgsql
as $$
DECLARE
BEGIN
    DELETE FROM person
    WHERE personid = personid_par;
END;
$$;

