create function login(username_par character varying, password_par character varying)
  returns integer
language plpgsql
as $$
DECLARE
    count integer;
BEGIN
    SELECT count(*) FROM person WHERE parkingguarddb.users.username like username_par and parkingguarddb.users.pw=password_par;
    if count > 0 then
        return parkingguarddb.users.userlevel;
    else
        return -1;
    end if;
END;
$$;

